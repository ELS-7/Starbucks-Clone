작동법 ) 
Visual Studio Code에서 작동
Extension에서 Live Server확장 프로그램 설치 후, Manage-Settings에서
Live Server › Settings: Host 설정을 cmd에서 파악한 개인 host 번호로 수정해야합니다.
이후 index.html에서 Go Live로 포팅을 진행하면 클론 웹 사이트가 전개됩니다.

웹 사이트 명은 Starbucks Korea - SCSA clone이며,
자세히 보기 등의 링크를 누르면 실제 스타벅스 코리아 웹 페이지로 이동하나, 외부사이트 이용 접속 경고가 발생함에 유의해주십시오.

기타 a href 링크들은 기본적으로 현 페이지, 혹은 연결 거부로 연결되며, 최하단 푸터의 커뮤니티 항목은 각 커뮤니티 페이지로 이동합니다.

모바일을 가정하여, 웹 페이지 크기를 변경하면 화면요소 또한 유연하게 변화합니다.


Todo
스타벅스 프로모션이
시작하자마자 열려있음 : 그로인해 열기버튼을 한번 눌러도 그대로고, 이후 닫기 눌러야 닫힘

프로모션 - 회색처리되어있는것 진하게


Done
헤더
function으로 사이트 주소 이름 지정
메뉴 : 검색이미지, coffee~what's new 및 호버 - css를 통해 dropdown했다가 흔들림 문제 - js연결로 작동
프로모션 : 자동 전개, 슬라이드 자동 이동반복, 중단/재생 및 현재 페이지 표기(원)
리워드 - visiable none-> null로 기본표기 설정
Brazil, Pick Your Favorite 광고 - css 조정
푸터(배경 검은부분) - 다른 링크들은 본래페이지로 이동, 커뮤니티는 해당 커뮤니티 링크로 이동
flexible resize - 화면 크기 조정시 요소들의 크기 및 배치 조절

Base - 스타벅스 웹 크롤링
